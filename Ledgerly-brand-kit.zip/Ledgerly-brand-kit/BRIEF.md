# Ledgerly brand and marketing brief

Everything you need to create Ledgerly's branding and marketing posts. Read it all before
writing anything. The files are in the folders next to this one (see **Files in this kit** at
the end).

---

## 1. The product in one breath

**Ledgerly is a budgeting app that turns your paychecks into a simple plan for the year, then
helps you track every month: what you spent, what's left and how your goals are doing.**

- Website: https://myledgerlyapp.com
- Web app (sign up and use it today): https://app.myledgerlyapp.com
- Help center: https://myledgerlyapp.com/help/
- Pricing: https://myledgerlyapp.com/#pricing
- Support email: support@myledgerlyapp.com
- iPhone and Android apps: **coming soon** (not in the stores yet). Today people use the web
  app on any phone or computer and can add it to their home screen.

### Taglines already in use (keep these consistent)

- Headline: **"Budget your money with clarity."**
- Eyebrow: **"Simple. Powerful. Yours."**
- Footer line: **"Better money habits. A brighter future."**
- Under the main button: **"Free to start. No credit card, no bank login."**
- How it works: **"From paycheck to plan in three steps."** Add your income → Give every dollar
  a job → Track as you go.

You may write new headlines, but they should sound like these.

---

## 2. Who it's for

1. **People living paycheck to paycheck who want control.** They get paid weekly, every two
   weeks or twice a month and want to know exactly what each paycheck has to cover.
2. **Planners and goal-setters.** Saving for an emergency fund, a trip, a house or retirement,
   and want to watch each goal fill up.
3. **Privacy-minded people** who don't want to hand a budgeting app their bank login.
4. **Small business owners and freelancers.** Ledgerly can keep a business budget and a
   personal budget, and a category in one (like "Owner's pay") can show up as income in the
   other automatically.
5. **Households and couples** who want separate budgets for different parts of life (Premium).

---

## 3. What makes Ledgerly different (lead with these)

- **Plans around your real paydays.** Enter take-home pay and how often you're paid; Ledgerly
  builds the year and even spots the months with an extra paycheck.
- **Every dollar gets a job.** You always see "left to assign", so nothing is unplanned.
- **Private by design.** No bank login, no ads, never sells your data. Receipts are read on
  your device; the photo is never uploaded. Download all your data or delete your account any
  time.
- **Receipt scanning.** Snap a receipt and Ledgerly fills in the purchase (Premium).
- **What-if plans.** Try a raise, a new car payment or a move without touching your real plan
  (Premium).
- **Bills that don't come every month.** Car insurance twice a year, holidays in December:
  Ledgerly plans for them in the right months (Premium).
- **Taxes and 401(k).** Plan with pay before taxes and retirement contributions (Premium).
- **Business pay that flows into your personal budget** (shared categories).
- **Works with AI assistants.** Connect an AI app like Claude and ask "How much is left for
  groceries?" or "Log $42 at Shell for gas" (Premium).
- **Syncs across devices**, with two-step sign-in.

### Things Ledgerly does NOT do (never imply otherwise)

- It does **not** connect to bank accounts or import bank transactions. You enter spending
  yourself or scan a receipt. Present this as a feature: "You see every dollar you spend."
- It is **not** a bank, does not move money, does not give financial, tax or investment advice.
- The phone apps are **not** in the App Store or Google Play yet.

---

## 4. Plans and pricing

| | Free | Premium |
| --- | --- | --- |
| Price | $0, stays free | **$99.99 a year** |
| Budgets | 1 | As many as you need |
| Spending categories | Up to 5 | Unlimited |
| Savings goals | 1 | Unlimited |
| Sync across devices, two-step sign-in, data export | ✓ | ✓ |
| Bills that aren't every month, category items | | ✓ |
| Repeating transactions and receipt scanning | | ✓ |
| Full insights and what-if plans | | ✓ |
| Pay before taxes, reminders and AI agents | | ✓ |

- Cancel any time. Premium lasts until the end of the year paid for; nothing entered is deleted.
- **Right now payments are in test mode: Premium is free while we test payments.** Until the
  owner says otherwise, posts must not ask people to pay $99.99. Say "Free to start" or
  "Premium is free while we test payments." Check with the owner before any pricing post.
- Promotion codes and QR codes for free Premium exist (for giveaways, beta testers, events);
  the owner creates them. Don't invent codes.

---

## 5. Visual identity

### Logo

- **The logo:** three mountain peaks above the name "Ledgerly". The two outer peaks are deep
  green, the middle (tallest) peak is teal, and the name is deep green in a bold, rounded
  geometric typeface. It suggests climbing toward your goals.
- **Stacked** (peaks above the name, the main version):  /
  , on white , and a white version for dark backgrounds and photos
  (, on navy ).
- **Horizontal** (peaks beside the name, for headers and narrow spaces):
   / , and  versions.
- **The peaks alone** (for small spaces and patterns):  / ,
  .
- **App icon:** white and teal peaks on a navy square. ,
  . Use it for profile pictures and avatars.
- Rules: the middle peak is always teal (#09C19B); the rest is deep green on light backgrounds
  or white on dark ones. Don't recolor, stretch, rotate, outline or add effects. Keep clear
  space around the logo at least the height of the middle peak. Minimum width: 100px for the
  stacked logo, 80px for the horizontal one. On busy photos, use the white version over a
  darker area.

### Colors

| Name | Hex | Use |
| --- | --- | --- |
| Navy | `#0F172A` | Main text, dark backgrounds, app icon background, the app's sidebar |
| Navy 2 | `#13213D` | Gradient partner for dark backgrounds |
| Action green | `#16A34A` | Buttons and calls to action ("Get started") |
| Dark green | `#15803D` | Button hover, emphasis |
| Logo teal | `#09C19B` | The logo's middle peak, highlights |
| Logo deep green | `#014038` | The logo's outer peaks and name, deep accents |
| App teal | `#10B981` | Savings, progress bars, positive numbers in the app |
| Spending navy | `#1E3A5F` | "Spending" in charts |
| Soft background | `#F5F7FB` / `#F8FAFC` | Page backgrounds |
| Line gray | `#E5EAF1` | Borders, dividers |
| Muted text | `#5B6B82` / `#64748B` | Secondary text |
| Amber | `#F59E0B` | Warnings only, sparingly |
| Red | `#EF4444` | Over budget only, sparingly |

Feel: mostly white and soft gray, navy text, green as the one strong accent. Dark navy
sections for contrast. No neon, no purple, no busy gradients. The app's brand gradient is
green: `#10B981 → #22C55E` at 135°.

### Typography

- **Inter** for everything (free on Google Fonts; the file is in `fonts/`).
- Headlines: Inter ExtraBold 800, tight letter spacing (−2% to −3%), sentence case.
- Body: Inter Regular 400 / Medium 500.
- Small eyebrow labels: uppercase, letter spaced (+15%), muted gray, 600 weight
  ("SIMPLE. POWERFUL. YOURS.").

### Look and feel

- Clean, calm, lots of white space, rounded cards (14–16px corners), soft shadows.
- Real app screenshots in a device frame or a floating card with a gentle tilt and shadow (see
  `screenshots/website/website-desktop-hero.png` for the style).
- Simple line icons (Lucide style, 2px stroke).
- Photos, if any: real, warm, everyday moments (kitchen table, phone in hand, paying a bill).
  No piles of cash, no luxury, no stressed people clutching their heads.

---

## 6. Voice and writing rules (important)

Ledgerly sounds like a calm, friendly person who is good with money: clear, encouraging and
never pushy.

- **Plain language.** Short sentences. Everyday words: "money you have", "left to spend",
  "what's left". Avoid finance jargon (no "zero-based budgeting", "allocations", "liquidity",
  "envelope method") unless explaining it.
- **Encouraging, never shaming.** "See where your money goes", not "Stop wasting money".
- **No hype.** No "revolutionary", "game-changing", "AI-powered", "crush your debt", "get
  rich". Few exclamation marks (at most one per post).
- **Spelling and punctuation:** curly apostrophes and quotes (’ “ ”), **no Oxford comma**
  ("rent, groceries and bills"), sentence case headlines, numbers as digits ($450, 3 steps).
- **Use the app's names for things:** Home, My Plan, Transactions, Insights, Savings goals,
  What-if plans, Left to assign, Left to spend, Premium.
- **Emoji:** optional and sparing (one or two per social post: 💰 📊 ✅ 🧾 🎯). None on the website.

### Claims: what you may and may not say

You may say:
- "No bank login", "No ads", "We never sell your data"
- "Receipts are read on your device; the photo is never uploaded"
- "Delete your account and everything in it, any time"
- "Encrypted in transit and at rest", "two-step sign-in"
- "Free to start, no credit card"

Never say:
- "Bank-level security", "100% secure", "military-grade", "hack-proof"
- Any promise of savings ("save $500 a month"), debt payoff or financial results
- "Connects to your bank", "automatic bank sync"
- "Available on the App Store / Google Play" (until the owner confirms launch)
- Names of the companies behind the app (hosting, database, payments, analytics)
- Made-up reviews, testimonials, ratings, user counts or press mentions. There are none yet.
- That it's financial, tax or legal advice

---

## 7. Content ideas

**Content pillars**
1. **How-to tips** using the app (one feature per post, with a screenshot).
2. **Money habits** (simple, practical budgeting tips: paying yourself first, planning for
   bills that aren't monthly, the three-paycheck months).
3. **Privacy** (budget without giving anyone your bank login).
4. **Behind the build** (a small, independent app made with care; updates and new features).
5. **Business owners** (keep business and personal money separate, pay yourself properly).

**Starter post ideas**
- "Paid every two weeks? Two months a year you get a third paycheck. Ledgerly finds them for
  you." (screenshot: `app-details/plan-months.png` or `app-phone/setup-pay.png`)
- "Give every dollar a job" explainer carousel (Add income → Plan it → Track it).
- "What's left to spend this month, at a glance." (`app-phone/phone-home.png`)
- "Snap the receipt. Ledgerly fills in the rest. The photo never leaves your phone."
- "Car insurance every 6 months? Plan for it in the right months." (`app-details/category-not-monthly.png`)
- "Try it before you live it: what-if plans." (`app-desktop/desktop-whatif-edit.png`)
- "Run a business? Pay yourself from your business budget and it shows up as income in your
  personal one." (`app-details/share-category.png`, `app-details/shared-income.png`)
- "Ask your AI assistant how much is left for groceries." (AI agents)
- "No bank login. No ads. Your budget is yours." (privacy pillar)
- Launch-list post: "The iPhone and Android apps are coming. Get one email at launch:
  myledgerlyapp.com"

**Calls to action** (pick one per post)
- "Start free at myledgerlyapp.com"
- "Get started free, no credit card"
- "Get one email when the apps launch: myledgerlyapp.com"

**Links with tracking** (use these so the owner can see which posts work):
`https://myledgerlyapp.com/?utm_source=<platform>&utm_medium=social&utm_campaign=<campaign>`
e.g. `?utm_source=instagram&utm_medium=social&utm_campaign=launch`

**Hashtags** (2–5 per post where the platform uses them): #budgeting #personalfinance
#budgetapp #moneytips #savingmoney #paycheckbudget #financialgoals #smallbusinessowner

---

## 8. Platform specs (common sizes)

| Placement | Size |
| --- | --- |
| Instagram / Facebook square post | 1080 × 1080 |
| Instagram portrait post | 1080 × 1350 |
| Stories / Reels / TikTok / Shorts | 1080 × 1920 (keep text out of the top and bottom 250px) |
| X / LinkedIn image | 1200 × 675 (X), 1200 × 627 (LinkedIn) |
| Profile picture | Use `logos/ledgerly-app-icon-1024.png` |
| YouTube thumbnail | 1280 × 720 |

---

## 9. About the screenshots

- All screenshots are of the real app in **light mode**, with a **made-up example budget**.
  The example person is "Alex Rivera". None of it is real customer data.
- You may crop, place in device frames, add arrows, highlights or captions. Don't edit the
  numbers or text inside the app screens.
- Phone screenshots: `screenshots/app-phone/` (1170 px wide for `phone-*.png`, 780 px for the others).
- Computer screenshots: `screenshots/app-desktop/` (1920 × 1230).
- Close-ups of single windows and cards: `screenshots/app-details/`.
- The website: `screenshots/website/` (desktop and phone, top of page and full page).
- More screenshots of every screen are on the help center: https://myledgerlyapp.com/help/
- Store-sized screenshots (for the App Store and Google Play) aren't made yet; ask the owner.

---

## 10. Before posting

- Check prices and the "free while we test payments" line with the owner.
- No posts saying the phone apps are out until the owner confirms launch.
- Every claim must match section 6.

---

## Files in this kit

```
BRIEF.md                         this file
logos/
  ledgerly-logo-stacked.svg / .png        peaks above the name (main logo), transparent
  ledgerly-logo-stacked-on-white.png      the same on white
  ledgerly-logo-stacked-white.svg / .png  white version for dark backgrounds and photos
  ledgerly-logo-stacked-white-on-navy.png the same on navy
  ledgerly-logo-horizontal(-white).svg / .png  peaks beside the name
  ledgerly-mark(-white).svg, ledgerly-mark.png  the peaks alone
  ledgerly-app-icon.svg / -1024.png       app icon (navy square)
  splash-2732.png                          the app's launch screen
fonts/
  inter-latin-wght-normal.woff2  Inter (variable weight); also free on Google Fonts
screenshots/
  app-phone/                     the app on a phone
  app-desktop/                   the app on a computer
  app-details/                   single windows and cards
  website/                       myledgerlyapp.com, desktop and phone
```
